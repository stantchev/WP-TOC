<?php 
    // Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;
?>
<div id='toc' class='wrap'>
    <h1 style="display:none;">&nbsp;</h1>
    <div class="toc-tab-panel">
        <a id="eztoc-welcome" class="eztoc-tablinks" data-href="no" href="#welcome"
           onclick="ezTocTabToggle(event, 'welcome')"><?php esc_html_e( 'Welcome', 'easy-table-of-contents' ) ?></a>
        <a id="eztoc-default" class="eztoc-tablinks" data-href="no" href="#general-settings"
           onclick="ezTocTabToggle(event, 'general')"><?php esc_html_e( 'Settings', 'easy-table-of-contents' ) ?></a>
        <a class="eztoc-tablinks" id="eztoc-technical" href="#technical-support"
           onclick="ezTocTabToggle(event, 'technical')" data-href="no"><?php esc_html_e( 'Help & Support', 'easy-table-of-contents' ) ?></a>
        <?php
        ?>
    </div><!-- /.Tab panel -->
    <div class="eztoc_support_div eztoc-tabcontent" id="welcome" style="display: block;"></div>
    <div class="eztoc-tabcontent" id="general">
        <div id="eztoc-tabs" style="margin-top: 10px;">
            <a href="#eztoc-general" id="eztoc-link-general" class="active"><?php esc_html_e( 'General', 'easy-table-of-contents' ) ?></a> | <a href="#eztoc-appearance" id="eztoc-link-appearance"><?php esc_html_e( 'Appearance', 'easy-table-of-contents' ) ?></a> | <a href="#eztoc-advanced" id="eztoc-link-advanced"><?php esc_html_e( 'Advanced', 'easy-table-of-contents' ) ?></a> | <a href="#eztoc-shortcode" id="eztoc-link-shortcode"><?php esc_html_e( 'Shortcode', 'easy-table-of-contents' ) ?></a> | <a href="#eztoc-sticky" id="eztoc-link-sticky"><?php esc_html_e( 'Sticky TOC', 'easy-table-of-contents' ) ?></a> | <a href="#eztoc-compatibility" id="eztoc-link-compatibility"><?php esc_html_e( 'Compatibility', 'easy-table-of-contents' ) ?></a> | <a href="#eztoc-iesettings" id="eztoc-link-iesettings"><?php esc_html_e( 'Import/Export', 'easy-table-of-contents' ) ?></a>
        </div>
        <form method="post" action="<?php echo esc_url(self_admin_url('options.php')); ?>" enctype="multipart/form-data">

            <div class="metabox-holder">

                <div class="postbox" id="eztoc-general">
                    <br />
                    <h3><span><?php esc_html_e('General', 'easy-table-of-contents'); ?></span></h3>

                    <div class="inside">

                        <table class="form-table">

                            <?php do_settings_fields('ez_toc_settings_general', 'ez_toc_settings_general'); ?>

                        </table>
                    </div><!-- /.inside -->
                </div><!-- /.postbox -->

            </div><!-- /.metabox-holder -->

            <div class="metabox-holder">

                <div class="postbox" id="eztoc-appearance">
                    <br />
                    <h3><span><?php esc_html_e('Appearance', 'easy-table-of-contents'); ?></span></h3>

                    <div class="inside">

                        <table class="form-table">

                            <?php do_settings_fields('ez_toc_settings_appearance', 'ez_toc_settings_appearance'); ?>

                        </table>

                    </div><!-- /.inside -->
                </div><!-- /.postbox -->

            </div><!-- /.metabox-holder -->

            <div class="metabox-holder">

                <div class="postbox" id="eztoc-advanced">
                    <br />
                    <h3><span><?php esc_html_e('Advanced', 'easy-table-of-contents'); ?></span></h3>

                    <div class="inside">

                        <table class="form-table">

                            <?php do_settings_fields('ez_toc_settings_advanced', 'ez_toc_settings_advanced'); ?>

                        </table>

                    </div><!-- /.inside -->
                </div><!-- /.postbox -->

            </div><!-- /.metabox-holder -->

            <div class="metabox-holder">

                <div class="postbox" id="eztoc-shortcode">
                    <br />
                    <h3><span><?php esc_html_e('Shortcode', 'easy-table-of-contents'); ?></span></h3>
                    <div class="inside">

                        <table class="form-table">
                            <?php do_settings_fields('ez_toc_settings_shortcode', 'ez_toc_settings_shortcode'); ?>
                        </table>

                    </div><!-- /.inside -->
                </div><!-- /.postbox -->

            </div><!-- /.metabox-holder -->

            <div class="metabox-holder">

            <div class="postbox" id="eztoc-sticky">
                <br />
                <h3><span><?php esc_html_e('Sticky TOC', 'easy-table-of-contents'); ?></span></h3>
                <div class="inside">

                    <table class="form-table">
                        <?php do_settings_fields('ez_toc_settings_sticky', 'ez_toc_settings_sticky'); ?>
                    </table>

                </div><!-- /.inside -->
            </div><!-- /.postbox -->

            </div><!-- /.metabox-holder -->

            <div class="metabox-holder">

                <div class="postbox" id="eztoc-compatibility">
                    <br />
                    <h3><span><?php esc_html_e('Compatibility', 'easy-table-of-contents'); ?></span></h3>
                    <div class="inside">

                        <table class="form-table">
                            <?php do_settings_fields('ez_toc_settings_compatibility', 'ez_toc_settings_compatibility'); ?>
                        </table>

                    </div><!-- /.inside -->
                </div><!-- /.postbox -->

            </div><!-- /.metabox-holder -->

            <div class="metabox-holder">

                <div class="postbox" id="eztoc-iesettings">
                    <br />
                    <h3><span><?php esc_html_e('Import/Export Settings', 'easy-table-of-contents'); ?></span></h3>
                    <div class="inside">

                        <table class="form-table">
                            <tbody>
                                <tr>
                                    <?php $url = wp_nonce_url(admin_url('admin-ajax.php?action=ez_toc_export_all_settings'), '_wpnonce'); ?>
                                    <th scope="row"><?php esc_html_e( 'Export Settings', 'easy-table-of-contents' ) ?></th>
                                    <td>
                                        <button type="button"><a href="<?php echo esc_url($url); ?>" style="text-decoration:none; color: black;">&nbsp;<?php esc_html_e('Export', 'easy-table-of-contents'); ?></a></button>
                                        <label> <br><?php esc_html_e('Export all ETOC settings to json file', 'easy-table-of-contents'); ?></label>
                                    </td>
                                </tr> 
                                <tr>
                                    <th scope="row"><?php esc_html_e( 'Import Settings', 'easy-table-of-contents' ) ?></th>
                                    <td>
                                        <input type="file" name="eztoc_import_backup" id="eztoc-import-backup">
                                        <label> <br><?php esc_html_e('Upload json settings file to import', 'easy-table-of-contents'); ?></label>
                                    </td>
                                </tr> 

                                <tr>
                                    <th scope="row"><?php echo esc_html__( 'Delete Data on Uninstall', 'easy-table-of-contents' ) ?></th>
                                    <td>
                                        <?php
                                        $ddou_value = ezTOC_Option::get( 'delete-data-on-uninstall', false ); 
                                        ezTOC_Option::checkbox(
                                            array(
                                                'id'      => 'delete-data-on-uninstall',
                                                'desc'    => esc_html__( 'This will remove all of its data when the plugin is deleted.', 'easy-table-of-contents' ),
                                                'default' => false,
                                            ),
                                            $ddou_value
                                        );
                                        ?>
                                    </td>
                                </tr>

                                <tr>
                                    <th scope="row"><?php esc_html_e( 'Migrate Table of Contents Plus', 'easy-table-of-contents' ) ?></th>
                                    <td>
                                    <?php $toc_plus_enbaled = class_exists('TOC_Plus') ? true : false; ?>
                                        <button type="button" name="eztoc_migrate_toc" id="eztoc_migrate_toc" class="button-primary" <?php if( ! $toc_plus_enbaled ){ echo esc_attr('disabled');}?> title="<?php echo !$toc_plus_enbaled ? esc_attr('Activate TOC+ to continue'):'';?>"><?php esc_html_e('Migrate Settings', 'easy-table-of-contents'); ?></button>
                                        <div id="eztoc-importer-loader" style="display: none;">&nbsp;<?php echo esc_html__('Migrating. Please wait...', 'easy-table-of-contents'); ?></div>
                                        <label> <br><?php esc_html_e('Migrate Settings from Table of Contents Plus. Make sure Table of Contents Plus is active while migrating', 'easy-table-of-contents'); ?></label>
                                    </td>
                                </tr>  
                                                
                            </tbody>
                        </table>

                    </div><!-- /.inside -->
                </div><!-- /.postbox -->

            </div><!-- /.metabox-holder -->

            <?php settings_fields('ez-toc-settings'); ?>
            <p class="submit">
                <?php submit_button(esc_html__( 'Save Changes', 'easy-table-of-contents'  ), 'primary large', 'submit', false) ; ?>
                <button type="button" id="reset-options-to-default-button" class="button button-primary button-large" style="background-color: #cd3241"><?php esc_html_e( 'Reset', 'easy-table-of-contents' ) ?></button>
            </p>
        </form>
    </div><!-- /.General Settings ended -->


    <div class="eztoc_support_div eztoc-tabcontent" id="technical">
        <div id="eztoc-tabs-technical">
            <a href="#" onclick="ezTocTabToggle(event, 'eztoc-technical-support',
            'eztoc-tabcontent-technical', 'eztoc-tablinks-technical')"
               class="eztoc-tablinks-technical active"><?php esc_html_e('Technical Support', 'easy-table-of-contents') ?></a>
            |
            <a href="#" onclick="ezTocTabToggle(event, 'eztoc-technical-how-to-use',
            'eztoc-tabcontent-technical', 'eztoc-tablinks-technical')"
               class="eztoc-tablinks-technical"><?php esc_html_e('How to Use', 'easy-table-of-contents') ?></a>
            |
            <a href="#" onclick="ezTocTabToggle(event, 'eztoc-technical-shortcode',
            'eztoc-tabcontent-technical', 'eztoc-tablinks-technical')"
               class="eztoc-tablinks-technical"><?php esc_html_e('Shortcode', 'easy-table-of-contents') ?></a>
            |
            <a href="https://stanchev.bg/" target="_blank" class="eztoc-tablinks-technical"><?php echo
                esc_html_e('Documentation', 'easy-table-of-contents') ?></a>
            |
            <a href="#" onclick="ezTocTabToggle(event, 'eztoc-technical-hooks-for-developers',
            'eztoc-tabcontent-technical', 'eztoc-tablinks-technical')"
               class="eztoc-tablinks-technical"><?php esc_html_e('Hooks (for Developers)', 'easy-table-of-contents') ?></a>
        </div>
        <div class="eztoc-form-page-ui">
            <div class="eztoc-left-side">
                <div class="eztoc-tabcontent-technical" id="eztoc-technical-support">
                    <h1><?php esc_html_e('Technical Support', 'easy-table-of-contents'); ?></h1>
                    <p class="ez-toc-tabcontent-technical-title-content"><?php esc_html_e('We are dedicated to provide Technical support & Help to our users. Use the below form for sending your questions.', 'easy-table-of-contents') ?> </p>
                    <p><?php esc_html_e('You can also contact us from ', 'easy-table-of-contents') ?><a
                                href="https://stanchev.bg/">https://stanchev.bg/</a>.</p>

                    <div class="eztoc_support_div_form" id="technical-form">
                        <ul>
                            <li>
                                <label class="ez-toc-support-label"><?php esc_html_e( 'Email', 'easy-table-of-contents' ) ?><span class="star-mark">*</span></label>
                                <div class="ez-toc-support-input">

                                    <input type="text" id="eztoc_query_email" name="eztoc_query_email"
                                           placeholder="<?php esc_html_e( 'Enter your Email', 'easy-table-of-contents' ) ?>" required style="width: 350px;"/>
                                </div>
                            </li>

                            <li>
                                <label class="ez-toc-support-label"><?php esc_html_e( 'Query', 'easy-table-of-contents' ) ?><span class="star-mark">*</span></label>

                                <div class="ez-toc-support-input">
                                    <label for="eztoc_query_message">
                                    <textarea rows="5" cols="50" id="eztoc_query_message"
                                              name="eztoc_query_message"
                                              placeholder="<?php esc_html_e( 'Write your query', 'easy-table-of-contents' ) ?>"></textarea></label>
                                </div>


                            </li>


                            <li>
                                <div class="eztoc-customer-type">
                                    <label class="ez-toc-support-label"><?php esc_html_e( 'Type', 'easy-table-of-contents' ) ?></label>
                                    <div class="ez-toc-support-input">
                                        <select name="eztoc_customer_type" id="eztoc_customer_type" style="width: 350px;">
                                            <option value="select"><?php esc_html_e( 'Select Customer Type', 'easy-table-of-contents' ) ?></option>
                                            <option value="free">
                                                <?php esc_html_e( 'Free', 'easy-table-of-contents' ) ?><span> <?php esc_html_e( '( Avg Response within 48-72 hrs)', 'easy-table-of-contents' ) ?></span>
                                            </option>
                                        </select>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <button class="button button-primary eztoc-send-query"><?php esc_html_e('Send Support Request', 'easy-table-of-contents'); ?></button>
                            </li>
                        </ul>
                        <div class="clear"></div>
                        <span class="eztoc-query-success eztoc-result eztoc_hide"><?php esc_html_e('Message sent successfully, Please wait we will get back to you shortly', 'easy-table-of-contents'); ?></span>
                        <span class="eztoc-query-error eztoc-result eztoc_hide"><?php esc_html_e('Message not sent. please check your network connection', 'easy-table-of-contents'); ?></span>
                    </div>
                </div>
                <div class="eztoc-tabcontent-technical" id="eztoc-technical-how-to-use" style="display:
                none;">
                    <h1><?php esc_html_e('How to Use', 'easy-table-of-contents'); ?></h1>
                    <p class="ez-toc-tabcontent-technical-title-content"><?php esc_html_e('You can check how to use `Easy Table of Contents`, follow the basic details below.', 'easy-table-of-contents'); ?></p>
                    <h3><?php esc_html_e('1. AUTOMATICALLY', 'easy-table-of-contents'); ?></h3>
                    <ol>
                        <li><?php esc_html_e('Go to the tab Settings > General section, check Auto Insert', 'easy-table-of-contents');
                            ?></li>
                        <li><?php esc_html_e('Select the post types which will have the table of contents automatically inserted.', 'easy-table-of-contents'); ?></li>
                        <li><?php esc_html_e('NOTE: The table of contents will only be automatically inserted on post types for which it has been enabled.', 'easy-table-of-contents'); ?></li>
                        <li><?php esc_html_e('After Auto Insert, the Position option for choosing where you want to display the `Easy Table of Contents`.', 'easy-table-of-contents'); ?></li>
                    </ol>
                    <h3><?php esc_html_e('2. MANUALLY', 'easy-table-of-contents'); ?></h3>
                    <p><?php esc_html_e('There are two ways for manual adding & display `Easy Table of Contents`:', 'easy-table-of-contents');
                        ?></p>
                    <ol>
                        <li><?php esc_html_e('Using shortcode, you can copy shortcode and paste the shortcode on editor of any post type.', 'easy-table-of-contents');
                            ?></li>
                        <li><?php esc_html_e('Using Insert table of contents option on editor of any post type.',
                                'easy-table-of-contents');
                            ?></li>
                        <li><?php esc_html_e('You have to choose post types on tab General > Enable Support section then `Easy Table of Contents` editor options would be shown to choose settings for particular post type.', 'easy-table-of-contents'); ?></li>
                    </ol>
                    <h3><?php esc_html_e('3. DESIGN CUSTOMIZATION', 'easy-table-of-contents');
                        ?></h3>
                    <ol>
                        <li><?php esc_html_e('Go to tab Settings > Appearance for design customization.', 'easy-table-of-contents');
                            ?></li>
                        <li><?php esc_html_e('You can change width of `Easy Table of Contents` from select Fixed or Relative sizes or you select custom width then it will be showing custom width option for enter manually width.', 'easy-table-of-contents');
                            ?></li>
                        <li><?php esc_html_e('You can also choose Alignment of `Easy Table of Contents`.', 'easy-table-of-contents');
                            ?></li>
                        <li><?php esc_html_e('You can also set Font Option of `Easy Table of Contents` according to your needs.', 'easy-table-of-contents');
                            ?></li>
                        <li><?php esc_html_e('You can also choose Theme color of `Easy Table of Contents` on Theme Options section according to your choice.', 'easy-table-of-contents');
                            ?></li>
                        <li><?php esc_html_e('You can also choose Custom Theme colors of `Easy Table of Contents`. according to your requirements', 'easy-table-of-contents');
                            ?></li>
                    </ol>
                    <h3><?php esc_html_e('4. STICKY TABLE', 'easy-table-of-contents');
                        ?></h3>
                    <ol>
                        <li><?php esc_html_e('Go to Sticky TOC tab to show Table of contents as sticky on your site.', 'easy-table-of-contents');
                            ?></li>
                        <li><?php esc_html_e('Select the post types on which sticky table of contents has been to be enabled.', 'easy-table-of-contents');
                            ?></li>
                        <li><?php esc_html_e('You can also decide whether to have sticky table of contents enabled on Homepage.', 'easy-table-of-contents');
                            ?></li>
                        <li><?php esc_html_e('You can also decide whether to have sticky table of contents enabled on Category|Tag.', 'easy-table-of-contents');
                            ?></li>
                        <li><?php esc_html_e('You can also decide whether to have sticky table of contents enabled on Product Category.', 'easy-table-of-contents');
                            ?></li>
                        <li><?php esc_html_e('You can also decide whether to have sticky table of contents enabled on Custom Taxonomy.', 'easy-table-of-contents');
                            ?></li>
                        <li><?php esc_html_e('You can also decide on which device you want to show sticky table of contents Mobile or Laptop.', 'easy-table-of-contents');
                            ?></li>
                        <li><?php esc_html_e('You can also decide the position of sticky table of contents on left or right.', 'easy-table-of-contents');
                            ?></li>
                        <li><?php esc_html_e('You can also choose Alignment of Sticky `Easy Table of Contents`.', 'easy-table-of-contents');
                            ?></li>
                        <li><?php esc_html_e('You can also decide whether the sticky toc should be opened by default on load.', 'easy-table-of-contents');
                            ?></li>
                        <li><?php esc_html_e('You can change width of Sticky `Easy Table of Contents` from select Fixed or Relative sizes or you select custom width then it will be showing custom width option for enter manually width.', 'easy-table-of-contents');
                            ?></li>
                        <li><?php esc_html_e('You can change height of Sticky `Easy Table of Contents` from select Fixed or Relative sizes or you select custom height then it will be showing custom height option for enter manually height.', 'easy-table-of-contents');
                            ?></li>
                        <li><?php esc_html_e('You can change Button Text of Sticky `Easy Table of Contents`.', 'easy-table-of-contents');
                            ?></li>
                        <li><?php esc_html_e('You can also choose Click TOC Close on Mobile of Sticky `Easy Table of Contents`.', 'easy-table-of-contents');
                            ?></li>
                        <li><?php esc_html_e('You can also choose Click TOC Close on desktop of Sticky `Easy Table of Contents`.', 'easy-table-of-contents');
                            ?></li>
                    </ol>
                    <h3><?php esc_html_e('5. MORE DOCUMENTATION:', 'easy-table-of-contents'); ?></h3>
                    <p><?php esc_html__('You can visit this link ', 'easy-table-of-contents') . '<a href="https://stanchev.bg/" target="_blank">' . esc_html__('More Documentation', 'easy-table-of-contents') . '</a>' . esc_html__(' for more documentation of `Easy Table of Contents`', 'easy-table-of-contents'); ?></p>
                </div>
                <div class="eztoc-tabcontent-technical" id="eztoc-technical-shortcode" style="display: none;">
                    <h1><?php esc_html_e('Shortcode', 'easy-table-of-contents'); ?></h1>
                    <p class="ez-toc-tabcontent-technical-title-content"><?php esc_html_e('Use the following shortcode within your content to have the table of contents display where you wish to:', 'easy-table-of-contents'); ?></p>
                    <table class="form-table">
                        <?php do_settings_fields('ez_toc_settings_shortcode', 'ez_toc_settings_shortcode'); ?>
                    </table>
                </div>
                <div class="eztoc-tabcontent-technical" id="eztoc-technical-hooks-for-developers" style="display:
                none;">
                    <h1><?php esc_html_e('Hooks (for Developers)', 'easy-table-of-contents'); ?></h1>
                    <p class="ez-toc-tabcontent-technical-title-content"><?php esc_html_e('This plugin has been designed for easiest way & best features for the users & also as well as for the developers, any developer follow the below advanced instructions:', 'easy-table-of-contents') ?> </p>

                    <h2><?php esc_html_e('Hooks', 'easy-table-of-contents') ?></h2>
                    <p><?php esc_html_e('Developer can use these below hooks for customization of this plugin:', 'easy-table-of-contents')
                        ?></p>
                    <h4><?php esc_html_e('Actions:', 'easy-table-of-contents') ?></h4>
                    <ul>
                        <li><code><?php esc_html_e('ez_toc_before', 'easy-table-of-contents') ?></code>
                        </li>
                        <li><code><?php esc_html_e('ez_toc_after', 'easy-table-of-contents')
                                ?></code></li>
                        <li>
                            <code><?php esc_html_e('ez_toc_sticky_toggle_before', 'easy-table-of-contents') ?></code>
                        </li>
                        <li>
                            <code><?php esc_html_e('ez_toc_sticky_toggle_after', 'easy-table-of-contents')
                                ?></code></li>
                        <li>
                            <code><?php esc_html_e('ez_toc_before_widget_container', 'easy-table-of-contents')
                                ?></code></li>
                        <li><code><?php esc_html_e('ez_toc_before_widget', 'easy-table-of-contents')
                                ?></code></li>
                        <li>
                            <code><?php esc_html_e('ez_toc_after_widget_container', 'easy-table-of-contents') ?></code>
                        </li>
                        <li><code><?php esc_html_e('ez_toc_after_widget', 'easy-table-of-contents')
                                ?></code></li>
                        <li>
                            <code><?php esc_html_e('ez_toc_title', 'easy-table-of-contents') ?></code>
                        </li>
                        <li>
                            <code><?php esc_html_e('ez_toc_sticky_title', 'easy-table-of-contents') ?></code>
                        </li>
                        <li>
                            <code><?php esc_html_e('ez_toc_container_class', 'easy-table-of-contents') ?></code>
                        </li>
                        <li>
                            <code><?php esc_html_e('ez_toc_widget_sticky_container_class', 'easy-table-of-contents') ?></code>
                        </li>
                        <li>
                            <code><?php esc_html_e('ez_toc_url_anchor_target', 'easy-table-of-contents') ?></code>
                        </li>
                        <li>
                            <code><?php esc_html_e('ez_toc_sticky_enable_support', 'easy-table-of-contents') ?></code>
                        </li>
                        <li>
                            <code><?php esc_html_e('ez_toc_sticky_post_types', 'easy-table-of-contents') ?></code>
                        </li>
                        <li>
                            <code><?php esc_html_e('ez_toc_modify_icon', 'easy-table-of-contents') ?></code>
                        </li>
                        <li>
                            <code><?php esc_html_e('ez_toc_label_below_html', 'easy-table-of-contents') ?></code>
                        </li>
                        <li>
                            <code><?php esc_html_e('eztoc_wordpress_final_output', 'easy-table-of-contents') ?></code>
                        </li>
                    </ul>


                    <h4><?php esc_html_e('Example: adding a span tag before the `Easy Table of Contents`',
                            'easy-table-of-contents') ?></h4>
                    <p><?php esc_html_e("Get this following code and paste into your theme's function.php file:", 'easy-table-of-contents') ?></p>
                    <pre>
add_action( 'ez_toc_before', 'addCustomSpan' );
function addCustomSpan()
{
    echo <span>Some Text or Element here</span>;
}
                       </pre>

                </div>
            </div>
            <div class="eztoc-right-side">
                <div class="eztoc-bio-box" id="ez_Bio" style="display:none;">
                    <h1><?php esc_html_e("Vision & Mission", 'easy-table-of-contents') ?></h1>
                    <p class="eztoc-p"><?php esc_html_e("We strive to provide the best TOC in the world.", 'easy-table-of-contents') ?></p>
                    <section class="eztoc_dev-bio">
                        <div class="ezoc-bio-wrap">
                            <img width="50px" height="50px"
                                 src="<?php echo esc_url(plugins_url('assets/img/ahmed-kaludi.jpg', dirname(__FILE__)))
                                 ?>" alt="ahmed-kaludi"/>
                            <p><?php esc_html_e('Lead Dev', 'easy-table-of-contents'); ?></p>
                        </div>
                        <div class="ezoc-bio-wrap">
                            <img width="50px" height="50px"
                                 src="<?php echo esc_url(plugins_url('assets/img/Mohammed-kaludi.jpeg', dirname(__FILE__))) 
                                 ?>" alt="Mohammed-kaludi"/>
                            <p><?php esc_html_e('Developer', 'easy-table-of-contents'); ?></p>
                        </div>
                        <div class="ezoc-bio-wrap">
                            <img width="50px" height="50px"
                                 src="<?php echo esc_url(plugins_url('assets/img/sanjeev.jpg', dirname(__FILE__))) ?>"
                                 alt="Sanjeev"/>
                            <p><?php esc_html_e('Developer', 'easy-table-of-contents'); ?></p>
                        </div>
                    </section>
                    <p class="eztoc_boxdesk"><?php esc_html_e('Delivering a good user experience means a lot to us, so we try our best to reply each and every question.', 'easy-table-of-contents'); ?></p>
                    <p class="ez-toc-company-link" style="display:none;"><?php esc_html_e('Support the innovation & development by upgrading to PRO ', 'easy-table-of-contents'); ?> <a href="#"><?php esc_html_e('I Want To Upgrade!', 'easy-table-of-contents'); ?></a></p>
                </div>
            </div>
        </div>
    </div>        <!-- /.Technical support div ended -->

    <!-- Removed PRO upsell content -->

    

</div>
